export default function Home({ params }: { params: { kw: string } }) {
	return null;
}
