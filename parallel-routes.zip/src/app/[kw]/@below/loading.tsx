export default function LoadingBelow() {
	return null;
}
