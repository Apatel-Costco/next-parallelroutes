export default function Loading() {
	return <p>loading</p>;
}
