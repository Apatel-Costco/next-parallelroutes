export default function Loader() {
	return <p>loading...</p>;
}
